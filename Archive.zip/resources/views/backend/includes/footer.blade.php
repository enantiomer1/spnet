<footer class="app-footer">
    <strong>{{ __('labels.general.copyright') }} &copy; {{ date('Y') }} <a href="http://laravel-boilerplate.com">{{ __('strings.backend.general.boilerplate_link') }}</a></strong> {{ __('strings.backend.general.all_rights_reserved') }}

    <span class="float-right">Powered by <a href="http://coreui.io">CoreUI</a></span>
</footer>